// This is a generated file. Do not edit. See application-descriptor.xml.
// WLClient configuration variables.
console.log("Running static_app_props.js");
var WL = WL ? WL : {};
WL.StaticAppProps = {
  "APP_DISPLAY_NAME": "MCHackathon",
  "APP_SERVICES_URL": "/apps/services/",
  "APP_ID": "com_ibm_MCHackathon",
  "APP_VERSION": "1.0.0",
  "WORKLIGHT_PLATFORM_VERSION": "7.1.0.0",
  "ENVIRONMENT": "iphone",
  "LOGIN_DISPLAY_TYPE": "embedded",
  "WORKLIGHT_NATIVE_VERSION": "2296531362",
  "mfpManualInit": false,
  "WORKLIGHT_ROOT_URL": "/apps/services/api/com_ibm_MCHackathon/iphone/"
};